MSEDCL SORTER ANDROID - V3 BUILD PACKAGE
========================================

लक्ष्य:
Android 15 वर चालणारे स्वतंत्र MSEDCL Sorter App. Windows प्रकल्पात कोणताही बदल नाही.

महत्त्वाचे:
- हा Android Studio source project आहे; तयार APK नाही.
- App चे HTML व JavaScript assets APK मध्ये समाविष्ट होतील.
- XLSX Style, JSZip, PDF.js, PDF.js Worker आणि PDF-Lib या पाच लायब्ररी GitHub Actions build दरम्यान डाउनलोड करून APK मध्ये जोडल्या जातील.
- APK तयार झाल्यानंतर PDF/Excel प्रक्रिया इंटरनेटशिवाय स्थानिक पातळीवर होण्यासाठी रचना केली आहे.
- GitHub Actions build यशस्वी होणे आणि प्रत्यक्ष Android 15 फोनवर PDF/Excel चाचणी होणे आवश्यक आहे. अद्याप प्रत्यक्ष फोन चाचणी झालेली नाही.

मोबाईलवरून APK Build करण्याची पद्धत:
1. ZIP फाईल फोनमध्ये डाउनलोड करून Extract करा.
2. github.com वर खाते उघडा/Sign in करा.
3. New repository तयार करा. नाव: msedcl-sorter-android
4. Extract केलेल्या MSEDCL_Sorter_Android_V2 फोल्डरमधील सर्व फाईल्स repository च्या root मध्ये upload करा. फोल्डरच्या आतल्या फाईल्स upload करा; वरचा parent folder पुन्हा nested करू नका.
5. Repository मध्ये .github/workflows/android.yml ही फाईल दिसते याची खात्री करा.
6. Actions tab उघडा. "Build MSEDCL Sorter Offline APK" workflow निवडा.
7. Run workflow दाबा आणि build पूर्ण होईपर्यंत थांबा.
8. हिरवा Success status आल्यावर त्या run मधील Artifacts विभागातून MSEDCL-Sorter-Android-APK डाउनलोड करा.
9. ZIP extract करून APK फोनमध्ये install करा. Android ने विचारल्यास त्या browser/file manager साठी install unknown apps परवानगी द्या.

App क्षमता/मर्यादा:
- HTML मध्ये Step 1, Step 2, Step 3 आणि PDF sorting चे उपलब्ध V14 workflow ठेवले आहे.
- Android file picker द्वारे एकापेक्षा अधिक PDF/Excel निवडण्याची सुविधा आहे.
- Generated blob downloads Downloads/MSEDCL Sorter मध्ये सेव्ह करण्यासाठी Android bridge आहे.
- मोठ्या PDF/ZIP फाईल्सची memory आणि download चाचणी प्रत्यक्ष फोनवर करणे बाकी आहे.
- APK मध्ये सर्व libraries bundled असतील तेव्हा App चे मुख्य processing offline असावे; प्रथम APK build साठी GitHub Actions ला internet लागेल.
- Android 15 targetSdk 35. minSdk 23.

Build workflow:
.github/workflows/android.yml
