package com.msedcl.sorter;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.*;
import android.net.Uri;
import android.provider.MediaStore;
import android.os.Environment;
import android.os.Build;
import android.widget.Toast;
import java.io.*;
import java.util.*;
import android.util.Base64;

public class MainActivity extends Activity {
 private WebView webView; private ValueCallback<Uri[]> fileCallback; private static final int FILE_CHOOSER=4102;
 private final Map<String,OutputStream> openFiles=new HashMap<>();
 @Override public void onCreate(Bundle state){super.onCreate(state);webView=new WebView(this);setContentView(webView);
  WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);s.setDefaultTextEncodingName("UTF-8");
  // Local packaged assets only. File-origin access is enabled for PDF.js local worker compatibility.
  s.setAllowFileAccessFromFileURLs(true);s.setAllowUniversalAccessFromFileURLs(true);
  webView.addJavascriptInterface(new SaveBridge(),"AndroidSave");
  webView.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=cb;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/pdf","application/vnd.ms-excel","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);try{startActivityForResult(i,FILE_CHOOSER);return true;}catch(Exception e){fileCallback=null;cb.onReceiveValue(null);return false;}}});
  webView.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView v,String u){injectDownloadHandler();}});webView.loadUrl("file:///android_asset/www/index.html");
 }
 private void injectDownloadHandler(){String js="(function(){if(window.__msedclDlHook)return;window.__msedclDlHook=true;const old=HTMLAnchorElement.prototype.click;HTMLAnchorElement.prototype.click=function(){const a=this;if(a.download&&a.href&&a.href.indexOf('blob:')===0){fetch(a.href).then(r=>r.blob()).then(async b=>{const token=AndroidSave.begin(a.download||'MSEDCL_Download',b.type||'application/octet-stream',b.size);if(!token)throw Error('Save could not start');const step=192*1024;for(let p=0;p<b.size;p+=step){const u=new Uint8Array(await b.slice(p,Math.min(p+step,b.size)).arrayBuffer());let bin='';for(let i=0;i<u.length;i+=8192)bin+=String.fromCharCode.apply(null,u.subarray(i,Math.min(i+8192,u.length)));AndroidSave.chunk(token,btoa(bin));}AndroidSave.finish(token);}).catch(e=>AndroidSave.fail(String(e)));return;}return old.call(a);};})();";webView.evaluateJavascript(js,null);}
 public class SaveBridge{
  @JavascriptInterface public synchronized String begin(String name,String mime,long size){try{String safe=(name==null?"MSEDCL_Download":name).replaceAll("[\\\\/:*?\\\"<>|]","_");OutputStream out;
   if(Build.VERSION.SDK_INT>=29){ContentValues cv=new ContentValues();cv.put(MediaStore.Downloads.DISPLAY_NAME,safe);cv.put(MediaStore.Downloads.MIME_TYPE,mime==null?"application/octet-stream":mime);cv.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/MSEDCL Sorter");Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv);if(uri==null)return "";out=getContentResolver().openOutputStream(uri);}
   else{File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"MSEDCL Sorter");if(!dir.exists()&&!dir.mkdirs())return "";out=new FileOutputStream(new File(dir,safe));}
   if(out==null)return "";String id=UUID.randomUUID().toString();openFiles.put(id,out);return id;
  }catch(Exception e){return "";}}
  @JavascriptInterface public synchronized void chunk(String id,String data){try{OutputStream o=openFiles.get(id);if(o!=null)o.write(Base64.decode(data,Base64.DEFAULT));}catch(Exception ignored){}}
  @JavascriptInterface public synchronized void finish(String id){try{OutputStream o=openFiles.remove(id);if(o!=null)o.close();runOnUiThread(()->Toast.makeText(MainActivity.this,"फाईल Downloads/MSEDCL Sorter मध्ये सेव्ह झाली",Toast.LENGTH_LONG).show());}catch(Exception ignored){}}
  @JavascriptInterface public void fail(String msg){runOnUiThread(()->Toast.makeText(MainActivity.this,"Download error: "+msg,Toast.LENGTH_LONG).show());}
 }
 @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==FILE_CHOOSER&&fileCallback!=null){Uri[] out=null;if(res==RESULT_OK&&data!=null){if(data.getClipData()!=null){int n=data.getClipData().getItemCount();out=new Uri[n];for(int i=0;i<n;i++)out[i]=data.getClipData().getItemAt(i).getUri();}else if(data.getData()!=null)out=new Uri[]{data.getData()};}fileCallback.onReceiveValue(out);fileCallback=null;}}
 @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
